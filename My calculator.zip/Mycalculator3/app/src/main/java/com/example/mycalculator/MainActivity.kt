package com.example.mycalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.mycalculator.R.id.powerButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var textView1 = findViewById<TextView>(R.id.textView1) // IIE, 2023
        val number1EditText = findViewById<EditText>(R.id.number1EditText) // IIE, 2023
        val number2EditText = findViewById<EditText>(R.id.number2EditText) // IIE, 2023
        val squareRootButton = findViewById<Button>(R.id.squareRootButton) // IIE, 2023
        val powerButton = findViewById<Button>(R.id.powerButton) // IIE, 2023
        val addButton = findViewById<Button>(R.id.addButton) // IIE, 2023

        val subtractButton = findViewById<Button>(R.id.subtractButton) // IIE, 2023

        val multiplyButton = findViewById<TextView>(R.id.multiplyButton) // IIE, 2023

        val divisionButton = findViewById<Button>(R.id.divisionButton) // IIE, 2023

        subtractButton?.setOnClickListener { // IIE, 2023
            var number1EditText = number1EditText.text.toString().toInt()
            var number2EditText = number2EditText.text.toString().toInt()
            var final = number1EditText - number2EditText
            textView1.text = "${number1EditText} - ${number2EditText} = ${final}"
            Log.v("FINAL", "The answer is")

        }

        addButton?.setOnClickListener { // IIE, 2023
            var number1EditText = number1EditText.text.toString().toInt()
            var number2EditText = number2EditText.text.toString().toInt()
            var final = number1EditText - number2EditText
            textView1.text = "${number1EditText} + ${number2EditText} = ${final}"
            Log.v("FINAL", "The answer is")

        }
        multiplyButton?.setOnClickListener { // IIE, 2023
            var numberOne = number1EditText.text.toString().toInt()
            var numberTwo = number2EditText.text.toString().toInt()
            var final = numberOne * numberTwo
            textView1.text = "S{numberOne} * S{numberTwo} = ${final}"
            Log.v("FINAL", "The answer is")

        }
        divisionButton?.setOnClickListener {// IIE, 2023
            var numberOne = number1EditText.text.toString().toInt()
            var numberTwo = number2EditText.text.toString().toInt()
            val final = numberOne / numberTwo
            val remainder = numberOne % numberTwo
            textView1.text = "S{numberOne}/ ${numberTwo} ${final} remainder ${remainder}"
            Log.v("FINAL", "The answer is")
        }
        powerButton.setOnClickListener { // IIE, 2023
            var base = number1EditText.text.toString().toDouble()
            var exponent = number2EditText.text.toString().toInt()

            var answer = 1.0
            for (i in 1..exponent) {
                answer = base
            }


            textView1.text = "$base^$exponent = $answer"

            Log.v("calculations", "${base}^${exponent} = ${answer}")

        }
        squareRootButton.setOnClickListener { // IIE, 2023
            val number1EditText = number1EditText.text.toString().toDouble()
            if (number1EditText >= 0) {
                val answer = Math.sqrt(number1EditText)
                textView1.text = "sqrt($number1EditText) = $answer"
                Log.v("calculations", "sqrt({$number1EditText})=${answer}")
            } else {
                val imaginaryAnswer = Math.sqrt(-number1EditText).toString() + "i"
                textView1.text = "sqrt(${number1EditText} = ${imaginaryAnswer}"
                Log.v("calculations", "sqrt({$number1EditText})= ${imaginaryAnswer}")

            }
        }
    }
}
// IIE, 2023,  The introduction to [IMAD,2023], The Independent Institution of Education






